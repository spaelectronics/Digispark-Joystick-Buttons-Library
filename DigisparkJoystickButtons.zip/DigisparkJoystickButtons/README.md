## Joystick Buttons Only Arduino Library for Digispark
The library can be used for push-button, momentary switches, toggle switch, magnetic contact switch (door sensor)... It handle upto 8 buttons.

Features
----------------------------
* Supports upto 8 Buttons
* All functions are non-blocking
* Uses watchdog feature to help prevent crashes.

Available Examples
----------------------------


Available Functions
----------------------------
* DigiButtons.setButtons(Byte)
* DigiButtons.delay()
* DigiButtons.update()

References
----------------------------

